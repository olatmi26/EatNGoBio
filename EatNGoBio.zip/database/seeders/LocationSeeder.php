<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Location;

class LocationSeeder extends Seeder
{
    public function run(): void
    {
        $stores = [
            'SAKA','ADMIRALTY','TOYIN','OGUNNAIKE','APAPA','RINGROAD','AGUNGI',
            'FESTAC','BODIJA','Bode Thomas','AJAO','AJOSE','GBAGADA','WUSE 2',
            'MAGODO','GWARINPA','YABA','AGIDINGBI','OGUDU','IKOTUN','AROMIRE',
            'ADMIRALTY II','OKOTA','EGBEDA','SANGOTEDO','ILUPEJU','IKORODU',
            'IDIMU','OKO OBA','IJU','GARKI','MARYLAND','ABEOKUTA','JAKANDE',
            'OTA','IKOYI','PH','SATELLITE','JABI MALL','GATEWAY MALL','ITIRE',
            'APO MALL','POLO PARK','KUBWA','AKURE','ILORIN','CALABAR','PH 2',
            'BADORE','UYO','Peter Odili','ASABA','BENIN-SAPELE','BENIN-UGBOWO',
            'ABA','WARRI','KANO BOMPAI','CHALLENGE','NYANYA','CHOBA','BARNAWA',
            'MINNA','ALI AKILU','AWKA','OWERRI','JOS','ABIOLA WAY','AKOBO',
            'LASU','SAWMILL Ikorodu','ONITSHA','IKOTA','AWOYAYA','PRIME MALL',
            'FREEDOM WAY','SURULERE','SHELL PH 2','PALMS Ibadan','ICM',
            'Aggrey Road','Kano Zoo','Ikeja','CHEVRON',
        ];

        $others = [
            ['name' => 'Central Support Unit (Head Office)', 'type' => 'Head Office', 'city' => 'Lagos'],
            ['name' => 'Magboro-Commissary (Commissary)',     'type' => 'Commissary',  'city' => 'Ogun'],
            ['name' => 'Portharcourt Commissary (Commissary)','type' => 'Commissary', 'city' => 'Port Harcourt'],
            ['name' => 'Abuja Commissary (Commissary)',       'type' => 'Commissary',  'city' => 'Abuja'],
            ['name' => 'LAGOS COMMISSARY (Commissary)',       'type' => 'Commissary',  'city' => 'Lagos'],
        ];

        foreach ($stores as $name) {
            Location::firstOrCreate(['name' => $name], [
                'type' => 'Store',
                'city' => 'Nigeria',
                'asset_count' => 0,
            ]);
        }

        foreach ($others as $loc) {
            Location::firstOrCreate(['name' => $loc['name']], [
                'type'        => $loc['type'],
                'city'        => $loc['city'],
                'asset_count' => 0,
            ]);
        }
    }
}
