<?php

namespace Database\Seeders;

use App\Models\Device;
use Illuminate\Database\Seeder;

/**
 * Seeds all 87 EatNGo store biometric devices.
 * Data sourced from: Update_on_Clock_in_device_installation_eatngo
 *
 * Run: php artisan db:seed --class=DeviceSeeder
 */
class DeviceSeeder extends Seeder
{
    public function run(): void
    {
        $devices = [
            // ── Already connected to ZKBioTime (keep syncing to our server too) ──
            ['serial_number' => 'BQC2235300158', 'name' => 'Central Support Unit',     'area' => 'HEAD OFFICE',          'ip_address' => '172.16.1.196'],
            ['serial_number' => 'ECV3235300053', 'name' => 'Magboro-Commissary',        'area' => 'Magboro-Commissary',   'ip_address' => '192.168.150.2'],
            ['serial_number' => 'BQC2254800046', 'name' => 'AGIDINGBI BIOMETRICS',      'area' => 'AGIDINGBI',            'ip_address' => '192.168.19.199'],
            ['serial_number' => 'BQC2254800045', 'name' => 'OGUDU BIOMETRICS',          'area' => 'OGUDU',                'ip_address' => '192.168.104.199'],
            ['serial_number' => 'BQC2254800021', 'name' => 'IKOTUN BIOMETRICS',         'area' => 'IKOTUN',               'ip_address' => '192.168.105.199'],
            ['serial_number' => 'BQC2254800020', 'name' => 'AROMIRE BIOMETRICS',        'area' => 'AROMIRE STORE',        'ip_address' => '192.168.101.199'],
            ['serial_number' => 'BQC2254800166', 'name' => 'EGBEDA STORE BIOMETRICS',   'area' => 'EGBEDA STORE',         'ip_address' => '192.168.25.199'],
            ['serial_number' => 'BQC2254800169', 'name' => 'ILUPEJU BIOMETRICS',        'area' => 'ILUPEJU',              'ip_address' => '192.168.108.199'],
            ['serial_number' => 'BQC2254800320', 'name' => 'TOYIN-STORE BIOMETRICS',    'area' => 'TOYIN STORE',          'ip_address' => '192.168.3.199'],
            ['serial_number' => 'BQC2254800346', 'name' => 'MARYLAND BIOMETRICS',       'area' => 'MARYLAND',             'ip_address' => '192.168.115.199'],

            // ── PDF Store List — All Remaining Devices ──
            ['serial_number' => 'BQC2254800326', 'name' => 'SAKA',              'area' => 'SAKA',           'ip_address' => '192.168.155.199'],
            ['serial_number' => 'BQC2254800342', 'name' => 'ADMIRALTY',         'area' => 'ADMIRALTY',      'ip_address' => '192.168.2.199'],
            ['serial_number' => 'BQC2254800364', 'name' => 'OGUNNAIKE',         'area' => 'OGUNNAIKE',      'ip_address' => '192.168.4.199'],
            ['serial_number' => 'BQC2254800319', 'name' => 'APAPA',             'area' => 'APAPA',          'ip_address' => '192.168.5.199'],
            ['serial_number' => 'BQC2254800366', 'name' => 'RING ROAD',         'area' => 'RING ROAD',      'ip_address' => '192.168.6.199'],
            ['serial_number' => 'BQC2254800396', 'name' => 'AGUNGI',            'area' => 'AGUNGI',         'ip_address' => '192.168.7.199'],
            ['serial_number' => 'BQC2254800378', 'name' => 'FESTAC',            'area' => 'FESTAC',         'ip_address' => '192.168.8.199'],
            ['serial_number' => 'BQC2254800363', 'name' => 'BODIJA',            'area' => 'BODIJA',         'ip_address' => '192.168.10.199'],
            ['serial_number' => 'BQC2254800397', 'name' => 'BODE-THOMAS',       'area' => 'BODE-THOMAS',    'ip_address' => '192.168.9.199'],
            ['serial_number' => 'BQC2254800023', 'name' => 'AJAO',              'area' => 'AJAO',           'ip_address' => '192.168.11.199'],
            ['serial_number' => 'BQC2254800343', 'name' => 'AJOSE',             'area' => 'AJOSE',          'ip_address' => '192.168.106.199'],
            ['serial_number' => 'BQC2254800356', 'name' => 'GBAGADA',           'area' => 'GBAGADA',        'ip_address' => '192.168.13.199'],
            ['serial_number' => 'BQC2254800355', 'name' => 'WUSE 2',            'area' => 'WUSE 2',         'ip_address' => '192.168.14.199'],
            ['serial_number' => 'BQC2254800107', 'name' => 'MAGODO',            'area' => 'MAGODO',         'ip_address' => '192.168.15.199'],
            ['serial_number' => 'BQC2254800354', 'name' => 'CHEVRON',           'area' => 'CHEVRON',        'ip_address' => '192.168.102.199'],
            ['serial_number' => 'BQC2254800382', 'name' => 'GWARINPA',          'area' => 'GWARINPA',       'ip_address' => '192.168.17.199'],
            ['serial_number' => 'BQC2254800047', 'name' => 'YABA',              'area' => 'YABA',           'ip_address' => '192.168.18.199'],
            ['serial_number' => 'BQC2254800032', 'name' => 'ADMIRALTY II',      'area' => 'ADMIRALTY II',   'ip_address' => '192.168.103.199'],
            ['serial_number' => 'BQC2254800174', 'name' => 'OKOTA',             'area' => 'OKOTA',          'ip_address' => '192.168.24.199'],
            ['serial_number' => 'BQC2254800168', 'name' => 'SANGOTEDO',         'area' => 'SANGOTEDO',      'ip_address' => '192.168.107.199'],
            ['serial_number' => 'BQC2254800170', 'name' => 'IKORODU',           'area' => 'IKORODU',        'ip_address' => '192.168.109.199'],
            ['serial_number' => 'BQC2254800167', 'name' => 'IDIMU',             'area' => 'IDIMU',          'ip_address' => '192.168.110.199'],
            ['serial_number' => 'BQC2254800362', 'name' => 'OKO OBA',           'area' => 'OKO OBA',        'ip_address' => '192.168.112.199'],
            ['serial_number' => 'BQC2254800345', 'name' => 'IJU',               'area' => 'IJU',            'ip_address' => '192.168.113.199'],
            ['serial_number' => 'BQC2254800321', 'name' => 'GARKI',             'area' => 'GARKI',          'ip_address' => '192.168.114.199'],
            ['serial_number' => 'BQC2254800347', 'name' => 'ABEOKUTA',          'area' => 'ABEOKUTA',       'ip_address' => '192.168.116.199'],
            ['serial_number' => 'BQC2254800360', 'name' => 'JAKANDE',           'area' => 'JAKANDE',        'ip_address' => '192.168.120.199'],
            ['serial_number' => 'BQC2254800197', 'name' => 'OTA',               'area' => 'OTA',            'ip_address' => '192.168.121.199'],
            ['serial_number' => 'BQC2254800323', 'name' => 'IKOYI',             'area' => 'IKOYI',          'ip_address' => '192.168.123.199'],
            ['serial_number' => 'BQC2254800198', 'name' => 'PH',                'area' => 'PH',             'ip_address' => '192.168.125.199'],
            ['serial_number' => 'BQC2254800200', 'name' => 'Satellite',         'area' => 'Satellite',      'ip_address' => '192.168.126.199'],
            ['serial_number' => 'BQC2254800203', 'name' => 'Jabi Mall',         'area' => 'Jabi Mall',      'ip_address' => '192.168.132.199'],
            ['serial_number' => 'BQC2254800201', 'name' => 'Gateway Mall',      'area' => 'Gateway Mall',   'ip_address' => '192.168.133.199'],
            ['serial_number' => 'BQC2254800202', 'name' => 'Itire',             'area' => 'Itire',          'ip_address' => '192.168.136.199'],
            ['serial_number' => 'BQC2254800068', 'name' => 'Apo Mall',          'area' => 'Apo Mall',       'ip_address' => '192.168.137.199'],
            ['serial_number' => 'BQC2254800058', 'name' => 'Polo Park',         'area' => 'Polo Park',      'ip_address' => '192.168.138.199'],
            ['serial_number' => 'BQC2254800067', 'name' => 'Kubwa',             'area' => 'Kubwa',          'ip_address' => '192.168.139.199'],
            ['serial_number' => 'BQC2254800065', 'name' => 'Akure',             'area' => 'Akure',          'ip_address' => '192.168.140.199'],
            ['serial_number' => 'BQC2254800066', 'name' => 'Ilorin',            'area' => 'Ilorin',         'ip_address' => '192.168.141.199'],
            ['serial_number' => 'BQC2254800124', 'name' => 'Calabar',           'area' => 'Calabar',        'ip_address' => '192.168.142.199'],
            ['serial_number' => 'BQC2254800122', 'name' => 'Shell Gate PH 2',   'area' => 'Shell Gate PH 2','ip_address' => '192.168.143.199'],
            ['serial_number' => 'BQC2254800115', 'name' => 'Jara Mall',         'area' => 'Jara Mall',      'ip_address' => '192.168.144.199'],
            ['serial_number' => 'BQC2254800123', 'name' => 'Badore',            'area' => 'Badore',         'ip_address' => '192.168.145.199'],
            ['serial_number' => 'BQC2254800103', 'name' => 'Uyo',               'area' => 'Uyo',            'ip_address' => '192.168.146.199'],
            ['serial_number' => 'BQC2254800071', 'name' => 'Peter-Odili',       'area' => 'Peter-Odili',    'ip_address' => '192.168.147.199'],
            ['serial_number' => 'BQC2254800256', 'name' => 'Asaba',             'area' => 'Asaba',          'ip_address' => '192.168.148.199'],
            ['serial_number' => 'BQC2254800121', 'name' => 'Benin-Sapele',      'area' => 'Benin-Sapele',   'ip_address' => '192.168.149.199'],
            ['serial_number' => 'BQC2254800373', 'name' => 'Benin-Ugbowo',      'area' => 'Benin-Ugbowo',   'ip_address' => '192.168.151.199'],
            ['serial_number' => 'BQC2254800331', 'name' => 'Aba',               'area' => 'Aba',            'ip_address' => '192.168.153.199'],
            ['serial_number' => 'BQC2254800328', 'name' => 'Kano Bompai',       'area' => 'Kano Bompai',    'ip_address' => '192.168.154.199'],
            ['serial_number' => 'BQC2254800329', 'name' => 'Warri',             'area' => 'Warri',          'ip_address' => '192.168.156.199'],
            ['serial_number' => 'BQC2254800112', 'name' => 'Extra',             'area' => 'SPARE',          'ip_address' => null],
            ['serial_number' => 'BQC2254800348', 'name' => 'Challenge',         'area' => 'Challenge',      'ip_address' => '192.168.158.199'],
            ['serial_number' => 'BQC2254800349', 'name' => 'Nyanya',            'area' => 'Nyanya',         'ip_address' => '192.168.159.199'],
            ['serial_number' => 'BQC2254800086', 'name' => 'Choba',             'area' => 'Choba',          'ip_address' => '192.168.160.199'],
            ['serial_number' => 'BQC2254800088', 'name' => 'Barnawa',           'area' => 'Barnawa',        'ip_address' => '192.168.161.199'],
            ['serial_number' => 'BQC2254800087', 'name' => 'Minna',             'area' => 'Minna',          'ip_address' => '192.168.162.199'],
            ['serial_number' => 'BQC2254800091', 'name' => 'Ali Akilu',         'area' => 'Ali Akilu',      'ip_address' => '192.168.163.199'],
            ['serial_number' => 'BQC2254800090', 'name' => 'Awka',              'area' => 'Awka',           'ip_address' => '192.168.164.199'],
            ['serial_number' => 'BQC2254800085', 'name' => 'Owerri',            'area' => 'Owerri',         'ip_address' => '192.168.165.199'],
            ['serial_number' => 'BQC2254800358', 'name' => 'Jos',               'area' => 'Jos',            'ip_address' => '192.168.167.199'],
            ['serial_number' => 'BQC2254800359', 'name' => 'Yenagoa',           'area' => 'Yenagoa',        'ip_address' => '192.168.168.199'],
            ['serial_number' => 'BQC2254800392', 'name' => 'Abiola Way',        'area' => 'Abiola Way',     'ip_address' => '192.168.169.199'],
            ['serial_number' => 'BQC2254800357', 'name' => 'Akobo',             'area' => 'Akobo',          'ip_address' => '192.168.170.199'],
            ['serial_number' => 'BQC2254800394', 'name' => 'Lasu-Iba',          'area' => 'Lasu-Iba',       'ip_address' => '192.168.166.199'],
            ['serial_number' => 'BQC2254800393', 'name' => 'Sawmill-Ikorodu',   'area' => 'Sawmill-Ikorodu','ip_address' => '192.168.171.199'],
            ['serial_number' => 'BQC2254800251', 'name' => 'Onitsha',           'area' => 'Onitsha',        'ip_address' => '192.168.172.199'],
            ['serial_number' => 'BQC2254800261', 'name' => 'Ikota',             'area' => 'Ikota',          'ip_address' => '192.168.173.199'],
            ['serial_number' => 'BQC2254800254', 'name' => 'Awoyaya',           'area' => 'Awoyaya',        'ip_address' => '192.168.174.199'],
            ['serial_number' => 'BQC2254800252', 'name' => 'Prime Mall',        'area' => 'Prime Mall',     'ip_address' => '192.168.175.199'],
            ['serial_number' => 'BQC2254800255', 'name' => 'Freedom',           'area' => 'Freedom',        'ip_address' => '192.168.176.199'],
            ['serial_number' => 'BQC2254800012', 'name' => 'Mowe Warehouse',    'area' => 'Mowe Warehouse', 'ip_address' => '192.168.177.199'],
        ];

        $this->command->info('Seeding ' . count($devices) . ' devices...');

        foreach ($devices as $device) {
            Device::updateOrCreate(
                ['serial_number' => $device['serial_number']],
                array_merge($device, ['status' => 'unknown'])
            );
        }

        $this->command->info('Done! All ' . count($devices) . ' EatNGo biometric devices registered.');
    }
}
