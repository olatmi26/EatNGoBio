<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Device;
use Carbon\Carbon;

/**
 * Mark devices as offline if they have not sent a heartbeat in 2 minutes
 */
class MarkDevicesOffline extends Command
{
    /**
     * The name and signature of the console command.
     * 
     * @var string
     */
    protected $signature   = 'devices:check-offline';
    protected $description = 'Mark devices as offline if they have not sent a heartbeat in 2 minutes';
 
    public function handle(): void
    {
        $threshold = Carbon::now()->subMinutes(2);
 
        $count = Device::where('online', true)
            ->where(function ($q) use ($threshold) {
                $q->where('last_seen', '<', $threshold)
                  ->orWhereNull('last_seen');
            })
            ->update(['online' => false]);
 
        if ($count > 0) {
            $this->info("{$count} device(s) marked offline.");
        }
    }
}
