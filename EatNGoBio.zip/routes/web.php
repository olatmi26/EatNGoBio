<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\AlertController;
use App\Http\Controllers\VendorController;
use App\Http\Controllers\WarrantyController;
use App\Http\Controllers\InfraController;
use App\Http\Controllers\MaintenanceCostController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AssetLifecycleController;
use App\Http\Controllers\AssetRegisterController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\MaintenanceCalendarController;
use App\Http\Controllers\SearchController;

// Auth routes (unauthenticated)
Route::middleware('guest')->group(function () {
    Route::get('/login',          [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login',         [AuthController::class, 'login']);
});

// Authenticated routes
Route::middleware(['auth', 'verified'])->group(function () {

    // Dashboards
    Route::get('/',                  [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/admin-dashboard',   [DashboardController::class, 'admin'])->name('admin.dashboard');
    

    // Settings
    Route::get('/settings',                    [SettingController::class, 'index'])->name('settings.index');
    Route::post('/settings',                   [SettingController::class, 'update'])->name('settings.update');

    // Profile
    Route::get('/profile',                     [ProfileController::class, 'index'])->name('profile.index');
    Route::put('/profile',                     [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password',            [ProfileController::class, 'updatePassword'])->name('profile.password');

    // Logout
    Route::post('/logout',                     [AuthController::class, 'logout'])->name('logout');

   
});
