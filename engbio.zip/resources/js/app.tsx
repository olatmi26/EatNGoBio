import { createRoot } from 'react-dom/client';
import { createInertiaApp } from '@inertiajs/react';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import '../css/app.css';
import './bootstrap';
import { ThemeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './Components/base/Toast';

// Provide a fallback error page if a page is missing or a 500 error occurs
async function resolveWithErrorFallback(name: string) {
    try {
        return await resolvePageComponent(
            `./Pages/${name}.tsx`,
            import.meta.glob('./Pages/**/*.tsx'),
        );
    } catch (e) {
        // Try to load a custom Error page if available, else fallback to a simple error component
        try {
            // Try the user-defined error page
            return await resolvePageComponent(
                `./Pages/Error.tsx`,
                import.meta.glob('./Pages/**/*.tsx'),
            );
        } catch (err) {
            // Fallback: define a basic error component inline
            return {
                default: () => (
                    <div style={{
                        padding: 32,
                        color: "#dc2626",
                        fontFamily: "sans-serif",
                        textAlign: "center",
                    }}>
                        <h1 style={{ fontSize: 32, marginBottom: 16 }}>Page Not Found</h1>
                        <p style={{ fontSize: 18 }}>
                            The page "<b>{name}</b>" could not be loaded.<br />
                            Please check the route or contact the administrator.
                        </p>
                    </div>
                )
            };
        }
    }
}

createInertiaApp({
    title: (title) => `${title} — EatNGo Biometrics`,
    resolve: resolveWithErrorFallback,
    setup({ el, App, props }) {
        createRoot(el).render(
            <ThemeProvider>
                <ToastProvider>
                    <App {...props} />
                </ToastProvider>
            </ThemeProvider>
        );
    },
    progress: { color: '#16a34a' },
});
